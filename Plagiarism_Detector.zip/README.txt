




							PLAGIARISM DETECTOR

					Project by Chitturi Sai Suman and Praneeth Kapila

				This Application detects Plagiarism among set of C Source Codes

		Please go throught the Following Instructions carefully before using the Application.


	1. This Project is licensed under GNU General Public License from GitHub.

	2. The test files shall be present in the Files_to_be_checked directory.

	3. Let the files be named with the format "file01.txt" and maximum file limit shall be 99 i.e., "file99.txt".

	4. Do not delete the Directory named Results.

	5. No Part of the code should be misused.

	6. This application is built using C language, so we couldn't provide a GUI application.

	7. This application is a CLI application, yet too powerful.


		For any queries or Feedback, please write to saisumanchitturi@gmail.com
